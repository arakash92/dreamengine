var path = require('path');
JSCLASS_PATH = path.dirname(__filename) + '/src';
require(JSCLASS_PATH + '/loader');
